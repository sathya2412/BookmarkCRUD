import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Bookmark } from 'src/app/core/models/bookmark.model';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AddBookmarkComponent } from '../add-bookmark/add-bookmark.component';
import { BookmarkService } from 'src/app/Service/bookmark.service';
import { select, Store } from '@ngrx/store';
import { addBookmarks, deleteBookmark, getBookmarks, getBookmarksSuccess } from 'src/app/store/Actions/bookmark.action';

import { BookmarkState } from 'src/app/store/Reducers/bookmark.reducers';
import { bookmark, bookmarkSelector } from 'src/app/store/Selector/bookmark.selector';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-bookmark-list',
  templateUrl: './bookmark-list.component.html',
  styleUrls: ['./bookmark-list.component.scss']
})
export class BookmarkListComponent implements OnInit, OnDestroy {
  public bookmarkList: Bookmark[] = [];
  public dataSource: Bookmark[] = [];
  public displayedColumns = ['name', 'url', 'group', 'delete'];
  public groupFilter = 'all';
  public bookmarks$ = this.bookmarkState.pipe(select(bookmarkSelector));
  done = new Subject();

  constructor(
    public formBuilder: FormBuilder,
    private bookmarkService: BookmarkService,
    private store: Store,
    private bookmarkState: Store<BookmarkState>,
    public dialog: MatDialog) {
  }

  ngOnInit(): void {
    this.store.dispatch(getBookmarks());
    this.bookmarks$
      .pipe(takeUntil(this.done))
      .subscribe((data) => {
        this.dataSource = JSON.parse(JSON.stringify(data));
        this.bookmarkList = [...this.dataSource];
      });
  }

  ngOnDestroy(): void {
    this.done.next();
    this.done.complete();
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(AddBookmarkComponent, {
      width: '400px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.store.dispatch(addBookmarks(result));
        this.groupFilter = 'all'
        this.filterData(this.groupFilter);
      }
    });
  }



  deleteItem(id: number): void {
    this.store.dispatch(deleteBookmark(id));
    this.filterData(this.groupFilter);
  }

  filterData(event: string): void {
    if (event === 'all') {
      this.store.dispatch(getBookmarks());
      return;
    }
    const originalData = [...this.dataSource];
    this.bookmarkList = originalData.filter((item: { group: string; }, i: number) => item.group == event);
  }

}


