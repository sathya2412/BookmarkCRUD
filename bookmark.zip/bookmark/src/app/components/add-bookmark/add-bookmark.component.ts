import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { select, Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Bookmark } from 'src/app/core/models/bookmark.model';
import { BookmarkState } from 'src/app/store/Reducers/bookmark.reducers';
import { bookmarkSelector } from 'src/app/store/Selector/bookmark.selector';

@Component({
  selector: 'app-add-bookmark',
  templateUrl: './add-bookmark.component.html',
  styleUrls: ['./add-bookmark.component.scss']
})
export class AddBookmarkComponent implements OnInit, OnDestroy {
  public dataSource: Bookmark[] = [];
  public bookmarks$ = this.bookmarkState.pipe(select(bookmarkSelector));
  done = new Subject();
  bookMarkform!: FormGroup;
  showForm = false;

  constructor(public dialogRef: MatDialogRef<AddBookmarkComponent>,
    private bookmarkState: Store<BookmarkState>,
    public formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.buildForm();
  }

  ngOnDestroy(): void {
    this.done.next();
    this.done.complete();
  }

  buildForm(): void {
    this.bookMarkform = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.maxLength(50)]),
      url: new FormControl('', [Validators.required]),
      group: new FormControl('', [Validators.required])
    });
    this.showForm = true;
  }




  /* public findDuplicate(control: AbstractControl): object | null {
     const name = control.value;  
     let duplicate = [];
     
     if (this.dataSource.length) {
       duplicate = this.dataSource.filter((item: { name: string; }) => item.name.toLowerCase() === name.toLowerCase());
     }   
 
     if (duplicate.length && name.length > 0) {
         return { duplicateName: true };
     } else {
         return null;
     }
 }   */

  closeDialog() {
    this.bookMarkform.controls.name.markAsTouched();
    this.bookMarkform.controls.url.markAsTouched();
    this.bookMarkform.controls.group.markAsTouched();

    if (this.bookMarkform.valid) {
      const data = {
        name: this.bookMarkform.value.name,
        url: this.bookMarkform.value.url,
        group: this.bookMarkform.value.group
      };
      this.dialogRef.close(data);
    } else {
      return;
    }

  }


}
