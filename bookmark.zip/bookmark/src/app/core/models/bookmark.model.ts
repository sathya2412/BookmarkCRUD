
export interface Bookmark {
    id?: number;
    name: string;
    url: string;
    group: string;
  }

export const BookmarkList: Bookmark[] = [{ name: "Angular", url: 'www.angular.org', group: "personal" },
{ name: "React", url: 'www.react.org', group: "work" },
{ name: "Vue", url: 'www.vue.org', group: "leisure" }];