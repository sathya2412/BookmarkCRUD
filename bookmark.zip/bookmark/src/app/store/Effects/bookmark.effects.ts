import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { EMPTY } from 'rxjs';
import {
  catchError,
  concatMap,
  exhaustMap,
  map,
  mergeMap,
  tap,
} from 'rxjs/operators';
import { BookmarkService } from 'src/app/Service/bookmark.service';
import {
  getBookmarks,
  getBookmarksSuccess,
  addBookmarks,
  addBookmarksSuccess,
  deleteBookmark,
  deleteBookmarkSuccess,
} from '../Actions/bookmark.action';


@Injectable()
export class BookmarkEffects {
  loadBookmark$ = createEffect(() =>
    this.action$.pipe(
      ofType(getBookmarks),
      exhaustMap(() =>
        this.bookmarkService.getBookmarks().pipe(
          map((bookmarks) => {
            return getBookmarksSuccess(bookmarks);
          }
          ),
          catchError(() => EMPTY)
        )
      )
    )
  );



  addBookmark$ = createEffect(() =>
    this.action$.pipe(
      ofType(addBookmarks),
      tap((bookmark) => console.log(bookmark)),
      concatMap(({ bookmark }) =>
        this.bookmarkService.addBookmarks(bookmark).pipe(
          map((newBookmark) => addBookmarksSuccess(newBookmark)),
          catchError(() => EMPTY)
        )
      )
    )
  );

  deleteBookmark$ = createEffect(() =>
    this.action$.pipe(
      ofType(deleteBookmark),
      mergeMap(({ bookmarkId }) =>
        this.bookmarkService.deleteBookmark(bookmarkId).pipe(
          map(() => deleteBookmarkSuccess(bookmarkId)),
          catchError(() => EMPTY)
        )
      )
    )
  );

  constructor(private action$: Actions, private bookmarkService: BookmarkService) { }
}