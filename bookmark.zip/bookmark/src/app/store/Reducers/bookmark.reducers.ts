
import {
  createReducer,
  on,
} from '@ngrx/store';
import { Bookmark } from 'src/app/core/models/bookmark.model';
import {
  addBookmarksSuccess,
  deleteBookmarkSuccess,
  getBookmarksSuccess,
} from '../Actions/bookmark.action';

export interface BookmarkState {
  bookmarks: ReadonlyArray<Bookmark>;
}

const initialState: ReadonlyArray<Bookmark> = [];

export const bookmarkReducer = createReducer(
  initialState,
  on(getBookmarksSuccess, (state, { bookmarks }) => [...bookmarks]),
  on(addBookmarksSuccess, (state, { bookmark }) => [...state, bookmark]),
  on(deleteBookmarkSuccess, (state, { bookmarkId }) =>
    state.filter((bookmark) => bookmark.id !== bookmarkId)
  )
);
