import { getSelectors, RouterReducerState } from '@ngrx/router-store';
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { Bookmark } from 'src/app/core/models/bookmark.model';
import { BookmarkState } from '../Reducers/bookmark.reducers';

export const bookmarkSelector = createSelector(
  (state: BookmarkState) => state.bookmarks,
  (bookmarks: ReadonlyArray<Bookmark>) => bookmarks
);

export const bookmarkUserSelector = createSelector(
  (state: BookmarkState) => state.bookmarks,
  (bookmarks: ReadonlyArray<Bookmark>, user: Readonly<string>) => {
    return bookmarks.filter((bookmark: Bookmark) => bookmark.name === user);
  }
);

export const bookmark = createSelector(
  bookmarkSelector,
  (bookmarks: ReadonlyArray<Bookmark>, { id }: {id: number}) => {
    return bookmarks.filter((m) => m.id === Number(id))[0];
  }
);