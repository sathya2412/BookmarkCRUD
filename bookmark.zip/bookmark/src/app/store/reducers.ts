
import {
  ActionReducerMap
} from '@ngrx/store';
import {
  bookmarkReducer,
  BookmarkState,
} from './Reducers/bookmark.reducers';

export const reducers: ActionReducerMap<BookmarkState> = {
  bookmarks: bookmarkReducer,
};

